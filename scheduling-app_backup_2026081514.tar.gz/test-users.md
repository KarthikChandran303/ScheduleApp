# Test Users

Generated for local/staging role testing on 2026-08-15. All accounts have the `unassigned` role and are view-only until promoted by a scheduler/admin.

| Name | Email | Password |
| --- | --- | --- |
| Oogway | `oogway@test.com` | `Oogway123` |
| Gandalf | `gandalf@test.com` | `Gandalf123` |
| Totoro | `totoro@test.com` | `Totoro123` |

Use these only as test credentials. Rotate or delete them before production use.
