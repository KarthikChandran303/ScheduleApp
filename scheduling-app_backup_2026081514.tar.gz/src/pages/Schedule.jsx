import { useEffect, useMemo, useRef, useState } from 'react';
import {
  collection,
  onSnapshot,
  setDoc,
  updateDoc,
  deleteDoc,
  doc,
  query,
  where,
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import DayTabs from '../components/DayTabs';
import ActivityForm from '../components/ActivityForm';
import { DATE_OPTIONS, DEFAULT_DATE, addMinutesToTime, findConflicts, getTimeSlots, toMinutes, minutesToTime, snapToNearestQuarter } from '../lib/schedule';

const TIME_SLOTS = getTimeSlots('08:00', '20:00', 30);
const CALENDAR_START_MINUTES = toMinutes('08:00');
const CALENDAR_END_MINUTES = toMinutes('20:00');

export default function Schedule({ view = 'weekly' }) {
  const { firebaseUser, isScheduler } = useAuth();
  const isDailyView = view === 'daily';
  const [activeDay, setActiveDay] = useState(DEFAULT_DATE);
  const [activities, setActivities] = useState([]);
  const [users, setUsers] = useState([]);
  const [unavailability, setUnavailability] = useState([]);
  const [editing, setEditing] = useState(null);
  const [viewing, setViewing] = useState(null);
  const [actionActivityId, setActionActivityId] = useState(null);
  const [showPublicSchedule, setShowPublicSchedule] = useState(false);
  const [draggedId, setDraggedId] = useState(null);
  const [dragHighlightCell, setDragHighlightCell] = useState(null);
  const dragHighlightCellRef = useRef(null);
  const dragOffsetMinutes = useRef(0);
  const [resizingId, setResizingId] = useState(null);
  const [resizingState, setResizingState] = useState(null); // { id, startTime, endTime }
  const resizingStateRef = useRef(null);
  const resizeSessionRef = useRef(null);
  const suppressActivityClick = useRef(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    if (!firebaseUser) return undefined;
    const activityQueries = isScheduler
      ? [query(collection(db, 'activities'))]
      : [
          query(collection(db, 'activities'), where('assignedTo', 'array-contains', firebaseUser.uid)),
          query(collection(db, 'activities'), where('isPublic', '==', true)),
        ];
    const activitySnapshots = new Map();
    const updateActivityState = () => {
      const merged = new Map();
      activitySnapshots.forEach((snap) => {
        snap.docs.forEach((activityDoc) => merged.set(activityDoc.id, { id: activityDoc.id, ...activityDoc.data() }));
      });
      setActivities([...merged.values()]);
    };
    const unsubs = [
      ...activityQueries.map((activityQuery, index) =>
        onSnapshot(activityQuery, (snap) => {
          activitySnapshots.set(index, snap);
          updateActivityState();
        })
      ),
      onSnapshot(query(collection(db, 'users')), (snap) =>
        setUsers(snap.docs.map((d) => ({ id: d.id, ...d.data() })))
      ),
      onSnapshot(
        isScheduler
          ? query(collection(db, 'unavailability'))
          : query(collection(db, 'unavailability'), where('userId', '==', firebaseUser.uid)),
        (snap) =>
        setUnavailability(snap.docs.map((d) => ({ id: d.id, ...d.data() })))
      ),
    ];
    return () => unsubs.forEach((u) => u());
  }, [firebaseUser, isScheduler, showPublicSchedule]);

  // Update current time every minute
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  const usersById = useMemo(() => Object.fromEntries(users.map((u) => [u.id, u])), [users]);

  const visibleActivities = isScheduler
    ? activities
    : activities.filter((activity) =>
        activity.assignedTo.includes(firebaseUser.uid) || (showPublicSchedule && activity.isPublic !== false)
      );

  const dayActivities = visibleActivities
    .filter((a) => a.day === activeDay)
    .sort((a, b) => a.startTime.localeCompare(b.startTime));
  const visibleDateOptions = isDailyView ? DATE_OPTIONS.filter((date) => date.value === activeDay) : DATE_OPTIONS;

  const calendarActivities = useMemo(
    () =>
      Object.fromEntries(
        visibleActivities.map((a) => [a.id, { ...a, assignedNames: a.assignedTo.map((id) => usersById[id]?.name || 'Unknown') }])
      ),
    [visibleActivities, usersById]
  );

  async function handleSave(activity) {
    if (activity.id) {
      const { id, ...data } = activity;
      const previousActivity = activities.find((item) => item.id === id);
      setActivities((currentActivities) =>
        currentActivities.map((item) => item.id === id ? { ...item, ...data } : item)
      );
      setEditing(null);
      try {
        await updateDoc(doc(db, 'activities', id), data);
      } catch (error) {
        if (previousActivity) {
          setActivities((currentActivities) =>
            currentActivities.map((item) => item.id === id ? previousActivity : item)
          );
        }
        throw error;
      }
      return;
    } else {
      const activityRef = doc(collection(db, 'activities'));
      const optimisticActivity = { id: activityRef.id, ...activity };
      setActivities((currentActivities) => [...currentActivities, optimisticActivity]);
      setEditing(null);

      try {
        await setDoc(activityRef, activity);
      } catch (error) {
        setActivities((currentActivities) =>
          currentActivities.filter((item) => item.id !== activityRef.id)
        );
        throw error;
      }
      return;
    }
    setEditing(null);
  }

  async function handleDelete(activity) {
    if (!confirm(`Delete "${activity.title}"?`)) return;
    await deleteDoc(doc(db, 'activities', activity.id));
  }

  async function handleDrop(dateValue, slotStart) {
    if (!draggedId) return;
    const activity = activities.find((item) => item.id === draggedId);
    if (!activity) return;

    const durationMinutes = toMinutes(activity.endTime) - toMinutes(activity.startTime);
    const maxStartMinutes = Math.max(CALENDAR_START_MINUTES, CALENDAR_END_MINUTES - durationMinutes);
    const boundedStartMinutes = Math.min(
      maxStartMinutes,
      Math.max(CALENDAR_START_MINUTES, toMinutes(slotStart))
    );
    const boundedStart = getAvailableDropStart(
      dateValue,
      minutesToTime(boundedStartMinutes),
      durationMinutes,
      activity.id
    );
    const newEnd = addMinutesToTime(boundedStart, durationMinutes);

    await updateDoc(doc(db, 'activities', activity.id), {
      day: dateValue,
      startTime: boundedStart,
      endTime: newEnd,
    });

    setDraggedId(null);
    setDragHighlightCell(null);
    dragHighlightCellRef.current = null;
    dragOffsetMinutes.current = 0;
  }

  function getAvailableDropStart(day, proposedStart, durationMinutes, draggedActivityId) {
    const maxStartMinutes = Math.max(CALENDAR_START_MINUTES, CALENDAR_END_MINUTES - durationMinutes);
    let startMinutes = Math.min(maxStartMinutes, Math.max(CALENDAR_START_MINUTES, toMinutes(proposedStart)));

    const endMinutes = startMinutes + durationMinutes;
    const firstConflict = activities
      .filter((activity) => {
        if (activity.id === draggedActivityId || activity.day !== day) return false;
        const activityStart = toMinutes(activity.startTime);
        const activityEnd = toMinutes(activity.endTime);
        return startMinutes < activityEnd && activityStart < endMinutes;
      })
      .sort((a, b) => toMinutes(a.startTime) - toMinutes(b.startTime))[0];

    if (!firstConflict) return minutesToTime(startMinutes);

    return minutesToTime(
      Math.min(maxStartMinutes, Math.max(CALENDAR_START_MINUTES, toMinutes(firstConflict.endTime)))
    );
  }

  async function handleResizeActivity(activityId, edge, newTime) {
    const activity = resizingStateRef.current || activities.find((item) => item.id === activityId);
    if (!activity) return;

    if (edge === 'start') {
      const endMinutes = toMinutes(activity.endTime);
      const newMinutes = Math.max(CALENDAR_START_MINUTES, Math.min(toMinutes(newTime), endMinutes - 15));
      if (newMinutes < endMinutes) {
        const nextState = { ...activity, startTime: minutesToTime(newMinutes) };
        resizingStateRef.current = nextState;
        setResizingState(nextState);
      }
    } else if (edge === 'end') {
      const startMinutes = toMinutes(activity.startTime);
      const newMinutes = Math.min(CALENDAR_END_MINUTES, Math.max(toMinutes(newTime), startMinutes + 15));
      if (newMinutes > startMinutes) {
        const nextState = { ...activity, endTime: minutesToTime(newMinutes) };
        resizingStateRef.current = nextState;
        setResizingState(nextState);
      }
    }
  }

  async function commitResize(activityId) {
    const finalState = resizingStateRef.current;
    if (!finalState) return;
    const startMinutes = Math.max(CALENDAR_START_MINUTES, toMinutes(finalState.startTime));
    const endMinutes = Math.min(CALENDAR_END_MINUTES, toMinutes(finalState.endTime));
    if (endMinutes - startMinutes < 15) {
      resizingStateRef.current = null;
      setResizingState(null);
      setResizingId(null);
      return;
    }
    const nextTimes = {
      startTime: minutesToTime(startMinutes),
      endTime: minutesToTime(endMinutes),
    };

    resizingStateRef.current = null;
    setResizingState(null);
    setResizingId(null);

    await updateDoc(doc(db, 'activities', activityId), nextTimes);
  }

  function startResize(event, activity, edge) {
    event.preventDefault();
    event.stopPropagation();
    event.currentTarget.setPointerCapture?.(event.pointerId);
    setActionActivityId(null);
    suppressActivityClick.current = true;
    setResizingId(activity.id);
    resizingStateRef.current = activity;
    setResizingState(activity);
    resizeSessionRef.current = {
      activityId: activity.id,
      edge,
      startY: event.clientY,
      originalTime: edge === 'start' ? activity.startTime : activity.endTime,
    };
  }

  function handleResizePointerMove(event) {
    const session = resizeSessionRef.current;
    if (!session) return;
    event.preventDefault();
    const deltaY = event.clientY - session.startY;
    const deltaMinutes = snapToNearestQuarter(Math.round(deltaY / 2.4));
    const newMinutes = toMinutes(session.originalTime) + deltaMinutes;
    handleResizeActivity(session.activityId, session.edge, minutesToTime(snapToNearestQuarter(newMinutes)));
  }

  async function finishResize(event) {
    const session = resizeSessionRef.current;
    if (!session) return;
    event.preventDefault();
    resizeSessionRef.current = null;
    await commitResize(session.activityId);
    window.setTimeout(() => {
      suppressActivityClick.current = false;
    }, 100);
  }

  function getCurrentTimePosition() {
    const hours = currentTime.getHours();
    const minutes = currentTime.getMinutes();
    const totalMinutes = hours * 60 + minutes;
    const slotHeightPx = 72;
    const slotMinutes = 30;
    const minutesFromCalendarStart = totalMinutes - CALENDAR_START_MINUTES;
    const visibleMinutes = Math.max(
      0,
      Math.min(CALENDAR_END_MINUTES - CALENDAR_START_MINUTES, minutesFromCalendarStart)
    );
    return (visibleMinutes / slotMinutes) * slotHeightPx;
  }

  function isToday(dateStr) {
    const today = new Date();
    const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    return dateStr === todayStr;
  }

  function isPastActivity(activity, day) {
    const localToday = `${currentTime.getFullYear()}-${String(currentTime.getMonth() + 1).padStart(2, '0')}-${String(currentTime.getDate()).padStart(2, '0')}`;
    if (day < localToday) return true;
    if (day > localToday) return false;
    return toMinutes(activity.endTime) <= currentTime.getHours() * 60 + currentTime.getMinutes();
  }

  return (
    <div className="page schedule-page">
      <div className="schedule-header">
        <h2>{isDailyView ? 'Daily schedule' : 'Weekly schedule'}</h2>
        {!isScheduler && (
          <label className="schedule-visibility-toggle">
            <input
              type="checkbox"
              checked={showPublicSchedule}
              onChange={(event) => setShowPublicSchedule(event.target.checked)}
            />
            <span className="schedule-toggle-track" aria-hidden="true"><span /></span>
            <span className="schedule-toggle-copy">
              <strong>{showPublicSchedule ? 'Public schedule' : 'My schedule'}</strong>
              <small>{showPublicSchedule ? 'Assigned + public activities' : 'Assigned activities only'}</small>
            </span>
          </label>
        )}
        {isScheduler && (
          <button
            className="primary-button"
            onClick={() => {
              setActionActivityId(null);
              setViewing(null);
              setEditing({ day: activeDay, startTime: '09:00', endTime: '10:00', assignedTo: [] });
            }}
          >
            + New activity
          </button>
        )}
      </div>

      <DayTabs activeDay={activeDay} onSelect={setActiveDay} />

      {editing && (
        <div className="modal-backdrop" onClick={() => setEditing(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>{editing.id ? 'Edit activity' : 'New activity'}</h2>
              <button type="button" className="modal-close" aria-label="Close dialog" onClick={() => setEditing(null)}>×</button>
            </div>
            <ActivityForm
              initial={editing}
              day={activeDay}
              users={users}
              unavailability={unavailability}
              onSave={handleSave}
              onCancel={() => setEditing(null)}
            />
          </div>
        </div>
      )}

      {viewing && (
        <div className="modal-backdrop" onClick={() => setViewing(null)}>
          <div className="modal activity-view-modal" onClick={(event) => event.stopPropagation()}>
            <div className="modal-header view-header">
              <div>
                <span className="view-eyebrow">Activity details</span>
                <h2>{viewing.title}</h2>
              </div>
              <button type="button" className="modal-close" aria-label="Close dialog" onClick={() => setViewing(null)}>×</button>
            </div>
            <div className="view-detail"><strong>When</strong><span>{viewing.day} · {viewing.startTime}–{viewing.endTime}</span></div>
            <div className="view-detail view-people-detail">
              <strong>People</strong>
              <div className="view-people-list">
                {viewing.assignedTo.length === 0 && <span>Unassigned</span>}
                {viewing.assignedTo.map((id) => (
                  <div key={id} className="view-person">
                    <strong>{usersById[id]?.name || 'Unknown'}</strong>
                    {viewing.personNotes?.[id] && <span>{viewing.personNotes[id]}</span>}
                  </div>
                ))}
              </div>
            </div>
            {viewing.venue && <div className="view-detail"><strong>Venue</strong><span>{viewing.venue}</span></div>}
            {viewing.description && <div className="view-detail view-description"><strong>Description</strong><span>{viewing.description}</span></div>}
            <div className="form-actions">
              <button type="button" className="secondary" onClick={() => setViewing(null)}>Close</button>
              {isScheduler && <button type="button" className="view-edit-action" onClick={() => { setViewing(null); setEditing(viewing); }}>Edit</button>}
            </div>
          </div>
        </div>
      )}

      <div className={`calendar-board ${isDailyView ? 'daily-view' : ''}`} role="grid" aria-label={`${isDailyView ? 'Daily' : 'Weekly'} schedule calendar`}>
        <div className="calendar-grid-header">
          <div className="time-column-label">Time</div>
          {visibleDateOptions.map((dateOption) => (
            <div
              key={dateOption.value}
              className={`calendar-date-header ${activeDay === dateOption.value ? 'active' : ''}`}
              onClick={() => setActiveDay(dateOption.value)}
            >
              <span>{dateOption.label}</span>
            </div>
          ))}
        </div>

        <div className="calendar-grid-body">
          <div className="calendar-time-column">
            {TIME_SLOTS.map((time) => (
              <div key={time} className="calendar-time-slot">
                {time}
              </div>
            ))}
          </div>

          {visibleDateOptions.map((dateOption) => (
            <div key={dateOption.value} className="calendar-day-column">
              {(() => {
                const draggedActivity = draggedId ? visibleActivities.find((item) => item.id === draggedId) : null;
                const highlightDay = dragHighlightCell?.slice(0, 10);
                const highlightStart = dragHighlightCell ? toMinutes(dragHighlightCell.slice(11)) : null;
                const draggedDuration = draggedActivity
                  ? toMinutes(draggedActivity.endTime) - toMinutes(draggedActivity.startTime)
                  : 0;
                const highlightEnd = highlightStart === null ? null : highlightStart + draggedDuration;

                return (
                  <>
              <div
                className={`current-time-indicator ${isToday(dateOption.value) ? 'is-today' : 'is-other-day'}`}
                style={{ top: `${getCurrentTimePosition()}px` }}
              />
              {TIME_SLOTS.map((time) => {
                const slotActivities = visibleActivities.filter(
                  (activity) => {
                    if (activity.day !== dateOption.value) return false;
                    const activityStart = toMinutes(activity.startTime);
                    const slotStart = toMinutes(time);
                    return activityStart >= slotStart && activityStart < slotStart + 30;
                  }
                );
                const cellKey = `${dateOption.value}-${time}`;
                const slotStart = toMinutes(time);
                const highlightMinutes =
                  draggedActivity &&
                  highlightDay === dateOption.value &&
                  highlightStart !== null &&
                  highlightEnd !== null
                    ? Math.max(0, Math.min(highlightEnd, slotStart + 30) - Math.max(highlightStart, slotStart))
                    : 0;
                const highlightOffsetMinutes =
                  highlightStart === null
                    ? 0
                    : Math.max(0, Math.max(highlightStart, slotStart) - CALENDAR_START_MINUTES);

                return (
                  <div
                    key={cellKey}
                    className={`calendar-slot ${activeDay === dateOption.value ? 'is-active' : ''} ${highlightMinutes > 0 ? 'drag-highlight' : ''} ${isScheduler && slotActivities.length === 0 ? 'is-clickable' : ''}`}
                    onClick={() => {
                      if (isScheduler && slotActivities.length === 0 && !draggedId && !resizingId) {
                        setActionActivityId(null);
                        setViewing(null);
                        setActiveDay(dateOption.value);
                        setEditing({
                          day: dateOption.value,
                          startTime: time,
                          endTime: addMinutesToTime(time, 30),
                          assignedTo: [],
                        });
                      }
                    }}
                    onDragOver={(event) => {
                      event.preventDefault();
                      if (draggedId) {
                        const slotBounds = event.currentTarget.getBoundingClientRect();
                        const cursorOffsetMinutes = ((event.clientY - slotBounds.top) / 72) * 30;
                        const proposedStart =
                          toMinutes(time) + cursorOffsetMinutes - dragOffsetMinutes.current;
                        const snappedStart = snapToNearestQuarter(proposedStart);
                        const dropStart = Math.max(
                          CALENDAR_START_MINUTES,
                          toMinutes(time) === CALENDAR_START_MINUTES &&
                            proposedStart < CALENDAR_START_MINUTES + 15
                            ? CALENDAR_START_MINUTES
                            : snappedStart
                        );
                        const draggedDuration =
                          toMinutes(draggedActivity?.endTime || time) - toMinutes(draggedActivity?.startTime || time);
                        const maxStartMinutes = Math.max(
                          CALENDAR_START_MINUTES,
                          CALENDAR_END_MINUTES - draggedDuration
                        );
                        const availableStart = getAvailableDropStart(
                          dateOption.value,
                          minutesToTime(Math.min(maxStartMinutes, dropStart)),
                          draggedDuration,
                          draggedId
                        );
                        const nextHighlight = `${dateOption.value}-${availableStart}`;
                        dragHighlightCellRef.current = nextHighlight;
                        setDragHighlightCell(nextHighlight);
                      }
                    }}
                    onDragLeave={() => {
                      dragHighlightCellRef.current = null;
                      setDragHighlightCell(null);
                    }}
                    onDrop={() => {
                      const dropStart =
                        dragHighlightCellRef.current?.slice(0, 10) === dateOption.value
                          ? dragHighlightCellRef.current.slice(11)
                          : time;
                      handleDrop(dateOption.value, dropStart);
                      setDragHighlightCell(null);
                      dragHighlightCellRef.current = null;
                      dragOffsetMinutes.current = 0;
                    }}
                  >
                    {highlightMinutes > 0 && (
                      <div
                        className="drag-highlight-overlay"
                        style={{
                          top: `${(highlightOffsetMinutes / 30) * 72}px`,
                          height: `${(highlightMinutes / 30) * 72}px`,
                        }}
                      />
                    )}
                    {slotActivities.map((activity) => {
                      const record = calendarActivities[activity.id];
                      const conflicts = activity.assignedTo
                        .flatMap((id) =>
                          findConflicts(activity, unavailability.filter((b) => b.userId === id)).map((c) => ({
                            ...c,
                            name: usersById[id]?.name || 'Unknown',
                          }))
                        );

                      // Use resizing state if currently resizing this activity
                      const displayActivity = resizingState?.id === activity.id ? resizingState : activity;
                      const startMinutes = toMinutes(displayActivity.startTime);
                      const endMinutes = toMinutes(displayActivity.endTime);
                      const durationMinutes = endMinutes - startMinutes;
                      const heightPx = (durationMinutes / 30) * 72; // 72px per 30 minutes
                      const activityTopPx = ((startMinutes - CALENDAR_START_MINUTES) / 30) * 72;
                      const showAssignees = durationMinutes >= 45;

                      return (
                        <div
                          key={activity.id}
                          className={`calendar-activity ${actionActivityId === activity.id ? 'is-selected' : ''} ${draggedId === activity.id ? 'is-dragging' : ''} ${isPastActivity(displayActivity, dateOption.value) ? 'is-past' : ''} ${resizingId === activity.id ? 'is-resizing' : ''}`}
                          style={{
                            height: `${heightPx}px`,
                            top: `${activityTopPx}px`,
                            '--activity-custom-color': displayActivity.color || '#cfe4ff',
                            '--activity-accent-color': displayActivity.color || '#2b8ab8',
                          }}
                          draggable={isScheduler && resizingId !== activity.id}
                          onDragStart={(event) => {
                            if (resizingStateRef.current) {
                              event.preventDefault();
                              return;
                            }
                            const activityBounds = event.currentTarget.getBoundingClientRect();
                            const durationMinutes = toMinutes(activity.endTime) - toMinutes(activity.startTime);
                            dragOffsetMinutes.current = Math.min(
                              durationMinutes,
                              Math.max(0, ((event.clientY - activityBounds.top) / 72) * 30)
                            );
                            setDraggedId(activity.id);
                            setActionActivityId(null);
                            setViewing(null);
                            event.dataTransfer.effectAllowed = 'move';
                          }}
                          onDragEnd={() => {
                            setDraggedId(null);
                            setDragHighlightCell(null);
                            dragHighlightCellRef.current = null;
                            dragOffsetMinutes.current = 0;
                          }}
                          onPointerMove={handleResizePointerMove}
                          onPointerUp={finishResize}
                          onClick={() => {
                            if (!resizingId && !suppressActivityClick.current) {
                              setActionActivityId((currentId) => currentId === activity.id ? null : activity.id);
                            }
                          }}
                        >
                          {isScheduler && (
                            <>
                              <div
                                className="activity-resize-handle top"
                                onPointerDown={(event) => startResize(event, activity, 'start')}
                              />
                              <div
                                className="activity-resize-handle bottom"
                                onPointerDown={(event) => startResize(event, activity, 'end')}
                              />
                            </>
                          )}
                          <div className="calendar-activity-content">
                            <div className="calendar-activity-title">{displayActivity.title}</div>
                            <div className="calendar-activity-time activity-detail-row">
                              <span aria-hidden="true">◷</span>
                              {displayActivity.startTime}–{displayActivity.endTime}
                            </div>
                            {showAssignees && (
                              <div className="calendar-activity-users activity-detail-row">
                                <span aria-hidden="true">♙</span>
                                {record?.assignedNames?.join(', ') || 'Unassigned'}
                              </div>
                            )}
                            {conflicts.length > 0 && (
                              <div className="calendar-activity-conflict">
                                ⚠ {conflicts.map((c) => c.name).join(', ')} unavailable
                              </div>
                            )}
                          </div>
                          <div
                            className={`calendar-activity-tooltip ${actionActivityId === activity.id ? 'is-open' : ''}`}
                            onClick={(event) => event.stopPropagation()}
                          >
                            <button type="button" className="activity-action view" onClick={() => { setActionActivityId(null); setViewing(activity); }}>View</button>
                            {isScheduler && <button type="button" className="activity-action edit" onClick={() => { setActionActivityId(null); setEditing(activity); }}>Edit</button>}
                            {isScheduler && <button type="button" className="activity-action delete" onClick={() => { setActionActivityId(null); handleDelete(activity); }}>Delete</button>}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                );
              })}
                  </>
                );
              })()}
            </div>
          ))}
        </div>
      </div>

      <div className="activity-list mobile-list">
        {dayActivities.length === 0 && <p className="empty-state">Nothing scheduled for this date.</p>}
        {dayActivities.map((activity) => {
          const assignedNames = activity.assignedTo.map((id) => usersById[id]?.name || 'Unknown');
          const conflicts = activity.assignedTo
            .flatMap((id) =>
              findConflicts(activity, unavailability.filter((b) => b.userId === id)).map((c) => ({
                ...c,
                name: usersById[id]?.name || 'Unknown',
              }))
            );

          return (
            <div key={activity.id} className="activity-card compact-card">
              <div className="activity-time">
                {activity.startTime}–{activity.endTime}
              </div>
              <div className="activity-body">
                <div className="activity-title">{activity.title}</div>
                <div className="activity-people">{assignedNames.join(', ') || 'Unassigned'}</div>
                {activity.venue && <div className="activity-venue">{activity.venue}</div>}
                {activity.description && <div className="activity-description">{activity.description}</div>}
                {conflicts.length > 0 && (
                  <div className="activity-conflict">
                    ⚠ {conflicts.map((c) => c.name).join(', ')} unavailable at this time
                  </div>
                )}
              </div>
              {isScheduler && (
                <div className="activity-actions">
                  <button className="icon-button" onClick={() => { setActionActivityId(null); setViewing(null); setEditing(activity); }}>
                    Edit
                  </button>
                  <button className="icon-button danger" onClick={() => handleDelete(activity)}>
                    Delete
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
