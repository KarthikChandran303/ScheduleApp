import { useEffect, useState } from 'react';
import {
  collection,
  query,
  where,
  onSnapshot,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { DATE_OPTIONS, getTimeSlots, toMinutes, minutesToTime, snapToNearestQuarter } from '../lib/schedule';

const TIME_SLOTS = getTimeSlots('08:00', '20:00', 30);
const DAY_START = toMinutes('08:00');
const DAY_END = toMinutes('20:00');

export default function Unavailability() {
  const { firebaseUser } = useAuth();
  const [blocks, setBlocks] = useState([]);
  const [day, setDay] = useState(DATE_OPTIONS[0]?.value || '');
  const [startTime, setStartTime] = useState('09:00');
  const [endTime, setEndTime] = useState('17:00');
  const [note, setNote] = useState('');
  const [dragging, setDragging] = useState(null);

  useEffect(() => {
    if (!firebaseUser) return;
    const q = query(collection(db, 'unavailability'), where('userId', '==', firebaseUser.uid));
    return onSnapshot(q, (snap) => setBlocks(snap.docs.map((d) => ({ id: d.id, ...d.data() }))));
  }, [firebaseUser]);

  async function handleAdd(e) {
    e.preventDefault();
    await addDoc(collection(db, 'unavailability'), {
      userId: firebaseUser.uid,
      day,
      startTime,
      endTime,
      note: note.trim(),
    });
    setNote('');
  }

  async function handleRemove(id) {
    await deleteDoc(doc(db, 'unavailability', id));
  }

  function updateBlockPreview(event, block, edge) {
    if (!dragging || dragging.id !== block.id) return;
    const deltaMinutes = snapToNearestQuarter(Math.round((event.clientY - dragging.startY) / 2.4));
    const originalStart = toMinutes(block.startTime);
    const originalEnd = toMinutes(block.endTime);
    const nextValue = edge === 'start' ? originalStart + deltaMinutes : originalEnd + deltaMinutes;
    const duration = originalEnd - originalStart;
    const nextStart = edge === 'move'
      ? Math.max(DAY_START, Math.min(DAY_END - duration, nextValue))
      : edge === 'start'
        ? Math.max(DAY_START, Math.min(nextValue, originalEnd - 15))
        : originalStart;
    const nextEnd = edge === 'move'
      ? nextStart + duration
      : edge === 'end'
        ? Math.min(DAY_END, Math.max(nextValue, originalStart + 15))
        : originalEnd;
    setDragging({ ...dragging, previewStart: minutesToTime(nextStart), previewEnd: minutesToTime(nextEnd) });
  }

  async function finishBlockDrag() {
    if (!dragging) return;
    const finalStart = dragging.previewStart || dragging.startTime;
    const finalEnd = dragging.previewEnd || dragging.endTime;
    setDragging(null);
    await updateDoc(doc(db, 'unavailability', dragging.id), {
      startTime: finalStart,
      endTime: finalEnd,
    });
  }

  function startBlockDrag(event, block, edge) {
    event.preventDefault();
    event.stopPropagation();
    event.currentTarget.setPointerCapture?.(event.pointerId);
    setDragging({
      id: block.id,
      edge,
      startY: event.clientY,
      startTime: block.startTime,
      endTime: block.endTime,
    });
  }

  const sorted = [...blocks].sort(
    (a, b) => (a.day || '').localeCompare(b.day || '') || a.startTime.localeCompare(b.startTime)
  );

  return (
    <div className="page">
      <h2>My unavailability</h2>
      <p className="page-subtitle">
        Mark times you're not available. Schedulers will see a warning if they try to assign you
        during a block.
      </p>

      <div className="availability-board" aria-label="Draggable unavailability schedule">
        <div className="availability-time-column">
          {TIME_SLOTS.map((slot) => <div key={slot}>{slot}</div>)}
        </div>
        <div className="availability-day-column">
          {TIME_SLOTS.map((slot) => <div key={slot} className="availability-slot" />)}
          {blocks.filter((block) => block.day === day).map((block) => {
            const startTime = dragging?.id === block.id && dragging.previewStart ? dragging.previewStart : block.startTime;
            const endTime = dragging?.id === block.id && dragging.previewEnd ? dragging.previewEnd : block.endTime;
            const top = ((toMinutes(startTime) - DAY_START) / 30) * 72;
            const height = ((toMinutes(endTime) - toMinutes(startTime)) / 30) * 72;
            return (
              <div
                key={block.id}
                className={`availability-block ${dragging?.id === block.id ? 'is-dragging' : ''}`}
                style={{ top: `${top}px`, height: `${height}px` }}
                onPointerMove={(event) => updateBlockPreview(event, block, dragging?.edge)}
                onPointerUp={finishBlockDrag}
              >
                <div className="availability-handle top" onPointerDown={(event) => startBlockDrag(event, block, 'start')} />
                <div className="availability-block-content" onPointerDown={(event) => startBlockDrag(event, block, 'move')}>
                  <strong>{startTime}–{endTime}</strong>
                  {block.note && <span>{block.note}</span>}
                </div>
                <div className="availability-handle bottom" onPointerDown={(event) => startBlockDrag(event, block, 'end')} />
              </div>
            );
          })}
        </div>
      </div>

      <form className="unavailability-form" onSubmit={handleAdd}>
        <div className="form-row">
          <label>
            Day
            <select value={day} onChange={(e) => setDay(e.target.value)}>
              {DATE_OPTIONS.map((dateOption) => (
                <option key={dateOption.value} value={dateOption.value}>
                  {dateOption.label}
                </option>
              ))}
            </select>
          </label>
          <label>
            From
            <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} />
          </label>
          <label>
            To
            <input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
          </label>
        </div>
        <label>
          Note (optional)
          <input value={note} onChange={(e) => setNote(e.target.value)} placeholder="e.g. doctor's appointment" />
        </label>
        <button type="submit">Add block</button>
      </form>

      <ul className="block-list">
        {sorted.map((b) => (
          <li key={b.id} className="block-item">
            <span>
              <strong>{b.day}</strong> {b.startTime}–{b.endTime}
              {b.note && <span className="block-note"> — {b.note}</span>}
            </span>
            <button className="link-button" onClick={() => handleRemove(b.id)}>
              Remove
            </button>
          </li>
        ))}
        {sorted.length === 0 && <p className="empty-state">No unavailability blocks yet.</p>}
      </ul>
    </div>
  );
}
